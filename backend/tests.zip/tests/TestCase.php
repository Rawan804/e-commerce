<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as BaseTestCase;

abstract class TestCase extends BaseTestCase
{
    /**
     * حماية: الاختبارات بتستعمل RefreshDatabase (migrate:fresh = بيمسح كل الجداول).
     * ممنوع تشتغل على قاعدة غير SQLite حتى ما تنمسح بيانات المشروع الحقيقية.
     * لازم تشغلها هيك:
     *   docker compose exec -e DB_CONNECTION=sqlite -e DB_DATABASE=":memory:" -e DB_URL="" app php artisan test
     */
    protected function setUpTraits()
    {
        $connection = $this->app['config']->get('database.default');

        if ($connection !== 'sqlite') {
            throw new \RuntimeException(
                "Refusing to run tests on '{$connection}' (RefreshDatabase would wipe it). ".
                'Run with: -e DB_CONNECTION=sqlite -e DB_DATABASE=:memory: -e DB_URL=""'
            );
        }

        return parent::setUpTraits();
    }
}